-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 13, 2023 at 06:30 PM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paginadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `precio` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `producto`
--

INSERT INTO `producto` (`id`, `nombre`, `tipo`, `precio`) VALUES
(81, 'Camion de Obras', '789D', 'Caterpilla'),
(82, 'Camion de Obras', '789D', 'Caterpilla'),
(83, 'Cargador de Cadenas', '953k', 'Caterpilla'),
(84, 'Cargador de Ruedas', '908K', 'Caterpilla'),
(85, 'Compactador', 'CS54B', 'Caterpilla'),
(86, 'Dragalina', '8000', 'Caterpilla'),
(87, 'Excavadora', '336', 'Caterpilla'),
(88, 'Manipulador de Material', 'MH3024', 'Caterpilla'),
(90, 'Manipulador de Material', 'MH3024', 'Caterpilla'),
(92, 'Dragalina', '8000', 'Caterpilla');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `name` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`name`, `lastname`, `email`, `pass`) VALUES
('Alfredo', 'Calderon', 'fredoklderon4@gmail.com', 'Partyhorse1'),
('David', 'Calderon', 'david@gmail.com', 'Partyhorse1'),
('admin', 'admin', 'admin@admin.com', 'admin'),
('David', 'Calderon', '111@gmail.com', 'david'),
('Osvaldo', 'Rangel', 'Osvaldo Puentes', 'osvaldo123'),
('Osvaldo', 'Rangel', 'Osvaldo Puentes', 'osvaldo123'),
('Osvaldo', 'Puentes', 'osvaldopuentes0502@gmail.com', 'Osvaldo3r34'),
('Priscila', 'Chavira', 'pr.ch.lu@hotmai.com', '123987'),
('Priscila', 'Chavira', 'pr.ch.lu@hotmai.com', '123987'),
('Priscila', 'Chavira', 'pr.ch.lu@hotmail.com', '123456789'),
('Damaris', 'Gamiz', 'damaris.y.gamiz@gmail.com', 'Gamiz230302'),
('muñeño', 'papi', 'papi@gmail.com', '1234'),
('Roobed', 'Trejo', 'roo@mail.com', '12345'),
('Roobed', 'Trejo', 'roo@mail.com', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles/style.css">
    <title>Document</title>
</head>
<body>

<h1>ZYZZPLEMENTS</h1>
<h3>Es hora de Administrar el OLIMPO</h3>
    
<div>
  <button class="usuarios"><a href="./read_users.php">Usuarios</a></button>
</div>
<div>
  <button class="inventario"><a href="./ver_inventario.php">Inventario</a></button>
</div>


<div>
  <button class="provedores"><a href="./provedores.php">Provedores</a></button>
</div>

<div>
  <button class="logout"><a href="./logout.php">LogOut</a></button>
</div>


</body>
</html>
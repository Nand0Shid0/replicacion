<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../styles/stylecre.css">
    <title>Sobre Nosotros</title>
</head>
<body>
    <div>
        <h1 class="titulo">Creadores y GymBros</h1>
    </div>

    <div class="descripcion">

        <p>Esta pagina ha sido desarrollada por Carlos Fernando Gurrola Alvarez y Jose Missael Barrera Salazar alumnos
            inscirtos a la Universidad Politecnica de Durango, actualmente cursando el 6to cuatrimestre de la carrera de 
            ingeneria en redes y telecomunicaciones
        </p>

        <img src="../imgs/imgs.jpg" height="500px" width="auto">
        <br><section>Encuentranos</section>

<footer class="footer-distributed">


  <div class="footer-left">

    <p class="footer-links">
      <a class="link-1" href="../welcome.php">Home</a>

      <a href="#">Blog</a>

      <a href="../admin/index.php">Admin</a>

      <a href="./contactanos.php">Contact</a>
    </p>

    <p>Zyzzplements &copy; 2022</p>
  </div>

</footer>

    </div>

    
</body>
</html>